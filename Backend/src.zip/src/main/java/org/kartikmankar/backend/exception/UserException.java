package org.kartikmankar.backend.exception;

public class UserException extends Exception {
    public UserException(String message){
        super(message);
    }
}
