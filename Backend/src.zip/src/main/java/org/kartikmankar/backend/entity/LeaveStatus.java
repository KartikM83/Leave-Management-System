package org.kartikmankar.backend.entity;

public enum LeaveStatus {

    PENDING,APPROVED,REJECTED
}
