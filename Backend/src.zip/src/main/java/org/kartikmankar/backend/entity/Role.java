package org.kartikmankar.backend.entity;

public enum Role {
    EMPLOYEE,MANAGER
}
